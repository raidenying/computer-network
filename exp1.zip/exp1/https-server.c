#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <malloc.h>
#include <sys/types.h>
#include <resolv.h>
#include "openssl/ssl.h"
#include "openssl/err.h"

/* ========== 全局配置 ========== */
#define CERT_FILE "keys/cnlab.cert"  // SSL证书路径
#define KEY_FILE "keys/cnlab.prikey"  // SSL私钥路径

SSL_CTX *ssl_ctx; // SSL全局上下文

/* ========== SSL初始化 ========== */
// 初始化OpenSSL库，加载证书和私钥
void init_openssl()
{
    SSL_library_init();  // 初始化OpenSSL库
    OpenSSL_add_all_algorithms();  // 添加所有加密算法
    SSL_load_error_strings();  // 加载错误字符串

    ssl_ctx = SSL_CTX_new(TLS_server_method());  // 创建SSL上下文
    // 加载证书和私钥
    if (!SSL_CTX_use_certificate_file(ssl_ctx, CERT_FILE, SSL_FILETYPE_PEM) ||
        !SSL_CTX_use_PrivateKey_file(ssl_ctx, KEY_FILE, SSL_FILETYPE_PEM))
    {
        exit(1);  // 如果加载失败，退出程序
    }
}

// 发送完整文件内容（200 OK）
void send_full_content(int client_fd, const char *path, SSL *ssl)
{
    int fd = open(path, O_RDONLY);  // 打开文件
    if (fd < 0) {  // 如果打开失败
        // 发送404响应
        if (ssl)
            SSL_write(ssl, "HTTP/1.1 404 Not Found\r\n\r\n", 26);
        else
            write(client_fd, "HTTP/1.1 404 Not Found\r\n\r\n", 26);
        if (ssl) SSL_free(ssl);  // 释放SSL资源
        close(client_fd);  // 关闭客户端连接
        return;
    }

    struct stat st;  // 定义一个结构体，用于存储文件状态
    if (fstat(fd, &st) < 0) {  // 获取文件状态
        close(fd);  // 关闭文件
        // 发送500响应
        if (ssl)
            SSL_write(ssl, "HTTP/1.1 500 Internal Server Error\r\n\r\n", 41);
        else
            write(client_fd, "HTTP/1.1 500 Internal Server Error\r\n\r\n", 41);
        if (ssl) SSL_free(ssl);
        close(client_fd);
        return;
    }

    char *content = malloc(st.st_size);  // 分配内存用于存储文件内容
    if (content == NULL)  // 如果内存分配失败
    {
        close(fd);
        // 发送500响应
        if (ssl)
            SSL_write(ssl, "HTTP/1.1 500 Internal Server Error\r\n\r\n", 41);
        else
            write(client_fd, "HTTP/1.1 500 Internal Server Error\r\n\r\n", 41);
        if (ssl) SSL_free(ssl);
        close(client_fd);
        return;
    }

    read(fd, content, st.st_size);  // 读取文件内容
    close(fd);  // 关闭文件

    char headers[1024];  // 定义一个数组用于存储HTTP头部
    // 构造HTTP头部
    snprintf(headers, sizeof(headers),
             "HTTP/1.1 200 OK\r\n"
             "Content-Length: %ld\r\n"
             "\r\n",
             st.st_size);

    SSL_write(ssl, headers, strlen(headers));  // 发送HTTP头部
    SSL_write(ssl, content, st.st_size);  // 发送文件内容
    SSL_free(ssl);  // 释放SSL资源
    free(content);  // 释放内存
    close(client_fd);  // 关闭客户端连接
}

// 处理Range请求（206 Partial Content）
void send_partial_content(int client_fd, const char *path, long start, long end, SSL *ssl)
{
    struct stat st;  // 定义一个结构体，用于存储文件状态
    if (stat(path, &st) < 0) {  // 获取文件状态
        SSL_write(ssl, "HTTP/1.1 404 Not Found\r\n\r\n", 26);  // 发送404响应
        SSL_free(ssl);  // 释放SSL资源
        close(client_fd);  // 关闭客户端连接
        return;
    }

    if (end < 0 || end >= st.st_size)  // 如果结束位置超出文件大小
    {
        end = st.st_size - 1;  // 设置结束位置为文件末尾
    }

    int fd = open(path, O_RDONLY);  // 打开文件
    if (fd < 0) {  // 如果打开失败
        SSL_write(ssl, "HTTP/1.1 404 Not Found\r\n\r\n", 26);  // 发送404响应
        SSL_free(ssl);
        close(client_fd);
        return;
    }

    lseek(fd, start, SEEK_SET);  // 定位到起始位置
    size_t length = end - start + 1;  // 计算要读取的长度
    char *content = malloc(length);  // 分配内存用于存储文件内容
    if (content == NULL) {  // 如果内存分配失败
        close(fd);
        SSL_write(ssl, "HTTP/1.1 500 Internal Server Error\r\n\r\n", 41);  // 发送500响应
        SSL_free(ssl);
        close(client_fd);
        return;
    }
    read(fd, content, length);  // 读取文件内容
    close(fd);  // 关闭文件

    char headers[1024];  // 定义一个数组用于存储HTTP头部
    // 构造HTTP头部
    snprintf(headers, sizeof(headers),
             "HTTP/1.1 206 Partial Content\r\n"
             "Content-Range: bytes %ld-%ld/%ld\r\n"
             "Content-Length: %ld\r\n\r\n",
             start, end, st.st_size, length);

    SSL_write(ssl, headers, strlen(headers));  // 发送HTTP头部
    SSL_write(ssl, content, length);  // 发送文件内容
    SSL_free(ssl);  // 释放SSL资源
    free(content);  // 释放内存
    close(client_fd);  // 关闭客户端连接
}

// 处理 HTTP 请求（80端口）：始终返回 301 重定向
void handle_http_request(int client_fd)
{
    char buffer[1024];  // 定义一个缓冲区用于存储客户端请求
    read(client_fd, buffer, sizeof(buffer));  // 读取客户端请求

    char *request_line = strtok(buffer, "\r\n");  // 获取请求行
    if (!request_line) {
        close(client_fd);  // 关闭客户端连接
        return;
    }
    char *method = strtok(request_line, " ");  // 获取请求方法
    char *path = strtok(NULL, " ");  // 获取请求路径
    if (!method || !path || strcasecmp(method, "GET") != 0)  // 如果方法不是GET
    {
        close(client_fd);  // 关闭客户端连接
        return;
    }
    char response[1024];  // 定义一个数组用于存储响应
    // 构造301重定向响应
    snprintf(response, sizeof(response),
             "HTTP/1.1 301 Moved Permanently\r\n"
             "Location: https://10.0.0.1%s\r\n\r\n",
             path);
    write(client_fd, response, strlen(response));  // 发送响应
    close(client_fd);  // 关闭客户端连接
}

// 处理 HTTPS 请求（443端口）
void handle_https_request(int client_fd)
{
    SSL *ssl = SSL_new(ssl_ctx);  // 创建SSL对象
    SSL_set_fd(ssl, client_fd);  // 设置SSL对象的文件描述符
    if (SSL_accept(ssl) <= 0) {  // 执行SSL握手
        SSL_free(ssl);  // 如果握手失败，释放SSL资源
        close(client_fd);  // 关闭客户端连接
        return;
    }

    char buffer[1024];  // 定义一个缓冲区用于存储客户端请求
    int n = SSL_read(ssl, buffer, sizeof(buffer) - 1);  // 读取客户端请求
    if (n <= 0) {
        SSL_free(ssl);  // 释放SSL资源
        close(client_fd);  // 关闭客户端连接
        return;
    }
    buffer[n] = '\0';  // 在请求末尾添加字符串终止符

    char method[16], req_path[256], protocol[16];  // 定义变量用于存储请求方法、路径和协议
    sscanf(buffer, "%s %s %s", method, req_path, protocol);  // 解析请求
    if (strcmp(method, "GET") != 0)  // 如果方法不是GET
    {
        SSL_free(ssl);  // 释放SSL资源
        close(client_fd);  // 关闭客户端连接
        return;
    }
    
    // 构造文件路径
    char full_path[512];
    snprintf(full_path, sizeof(full_path), "./%s", req_path + 1);

    // 如果路径是目录，则追加 index.html
    struct stat st;
    if (stat(full_path, &st) == 0 && S_ISDIR(st.st_mode)) {
        strncat(full_path, "/index.html", sizeof(full_path) - strlen(full_path) - 1);
    }

    // 如果文件不存在则返回 404
    if (access(full_path, F_OK) != 0)
    {
        SSL_write(ssl, "HTTP/1.1 404 Not Found\r\n\r\n", 26);  // 发送404响应
        SSL_free(ssl);  // 释放SSL资源
        close(client_fd);  // 关闭客户端连接
        return;
    }

    // 检查 Range 头实现 206 部分内容响应
    char *range_header = strstr(buffer, "Range: bytes=");  // 查找Range头
    if (range_header) 
    {
        long start = 0, end = -1;
        if (sscanf(range_header, "Range: bytes=%ld-%ld", &start, &end) < 2) {  // 解析Range头
            end = -1;
        }
        send_partial_content(client_fd, full_path, start, end, ssl);  // 发送部分内容
    } 
    else 
    {
        send_full_content(client_fd, full_path, ssl);  // 发送完整内容
    }
}

// HTTP监听线程（80端口）：仅处理重定向
void *start_http_listener(void *arg)
{
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);  // 创建套接字
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));  // 初始化服务器地址结构体
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;  // 绑定到所有可用地址
    server_addr.sin_port = htons(80);  // 绑定到80端口

    bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr));  // 绑定套接字
    listen(sockfd, 10);  // 监听套接字
    while (1)
    {
        int client_fd = accept(sockfd, NULL, NULL);  // 接受客户端连接
        handle_http_request(client_fd);  // 处理HTTP请求
    }
    return NULL;
}

// HTTPS监听线程（443端口）
void *start_https_listener(void *arg)
{
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);  // 创建套接字
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));  // 初始化服务器地址结构体
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;  // 绑定到所有可用地址
    server_addr.sin_port = htons(443);  // 绑定到443端口

    bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr));  // 绑定套接字
    listen(sockfd, 10);  // 监听套接字
    while (1)
    {
        int client_fd = accept(sockfd, NULL, NULL);  // 接受客户端连接
        handle_https_request(client_fd);  // 处理HTTPS请求
    }
    return NULL;
}

int main()
{
    init_openssl();  // 初始化OpenSSL
    pthread_t http_thread, https_thread;
    pthread_create(&http_thread, NULL, start_http_listener, NULL);  // 创建HTTP监听线程
    pthread_create(&https_thread, NULL, start_https_listener, NULL);  // 创建HTTPS监听线程
    pthread_join(http_thread, NULL);  // 等待HTTP监听线程结束
    pthread_join(https_thread, NULL);  // 等待HTTPS监听线程结束
    SSL_CTX_free(ssl_ctx);  // 释放SSL上下文
    return 0;
}