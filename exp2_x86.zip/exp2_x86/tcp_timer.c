#include "tcp.h"
#include "tcp_timer.h"
#include "tcp_sock.h"

#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>

// 全局链表 timer_list 用于保存所有处于 TIME_WAIT 状态的 tcp_timer
static struct list_head timer_list;
// 互斥锁，保护 timer_list 的访问，防止多个线程同时操作链表
static pthread_mutex_t timer_list_lock = PTHREAD_MUTEX_INITIALIZER;
// 定时器基准时间（单位：微秒），用于计算相对超时时间
static uint64_t base_time = 0;

/*
 * 函数: current_time_us
 * ---------------------
 * 获取当前时间（单位：微秒）
 */
static uint64_t current_time_us()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (uint64_t)tv.tv_sec * 1000000 + tv.tv_usec;
}

/*
 * 函数: tcp_scan_timer_list
 * ---------------------------
 * 遍历全局 timer_list 链表，查找超时的 TIME_WAIT 定时器，
 * 对于超时的定时器：
 *   1. 从链表中删除该定时器节点；
 *   2. 禁用定时器；
 *   3. 通过宏 timewait_to_tcp_sock 将 tcp_timer 转换为对应的 tcp_sock，
 *      并调用 tcp_sock_close() 释放 TCP 连接资源。
 *
 * 注意：整个操作过程中使用互斥锁保护 timer_list 链表的线程安全。
 */
void tcp_scan_timer_list()
{
    //log(DEBUG,"enter tcp_scan_timer_list");
    // 计算当前相对时间：当前时间减去程序启动时的基准时间
    uint64_t now = current_time_us() - base_time;
    struct tcp_timer *t, *tmp;

    // 上锁保护 timer_list
    pthread_mutex_lock(&timer_list_lock);
    // 使用安全遍历宏，遍历 timer_list 链表中所有定时器节点
    list_for_each_entry_safe(t, tmp, &timer_list, list)
    {
        // 如果该定时器已启用，且当前相对时间大于或等于设置的超时值
        if (t->enable && now >= (uint64_t)t->timeout)
        {
            fprintf(stdout, "tcp_scan_timer_list: TIME_WAIT timer expired, timer=%d, now=%llu\n",
                    t->timeout, now);
            // 从链表中删除该定时器节点
            list_delete_entry(&t->list);
            // 禁用该定时器，避免重复处理
            t->enable = 0;
            // 通过宏转换，获得对应的 tcp_sock 指针
            struct tcp_sock *tsk = timewait_to_tcp_sock(t);
            // 关闭 TCP 连接，释放资源
            tcp_set_state(tsk,TCP_CLOSED);
            //自动调用free
            tcp_bind_unhash(tsk);
            tcp_unhash(tsk);
            //log(DEBUG,"get out 1");
        }
    }
    //log(DEBUG,"get out 2");
    pthread_mutex_unlock(&timer_list_lock);

}

/*
 * 函数: tcp_set_timewait_timer
 * ----------------------------
 * 当 TCP 连接进入 TIME_WAIT 状态时，设置其定时器，并将该定时器节点挂入全局 timer_list 链表尾部。
 *
 * 具体步骤：
 *   1. 计算当前相对时间；
 *   2. 设置 tcp_timer 结构体的各个字段：
 *      - type 设为 0，表示 TIME_WAIT 定时器；
 *      - timeout = 当前相对时间 + TCP_TIMEWAIT_TIMEOUT（单位：微秒）；
 *      - enable 设为 1，表示定时器处于启用状态；
 *   3. 上锁后将定时器节点加入 timer_list 链表尾部，再释放锁。
 */
void tcp_set_timewait_timer(struct tcp_sock *tsk)
{
    // 计算当前相对时间（单位：微秒）
    uint64_t now = current_time_us() - base_time;

    // 初始化 tcp_timer 结构体中的字段
    tsk->timewait.type = 0; // TIME_WAIT 类型
    tsk->timewait.timeout = (int)(now + TCP_TIMEWAIT_TIMEOUT);
    tsk->timewait.enable = 1;

    // 上锁保护 timer_list，将该定时器加入链表尾部
    pthread_mutex_lock(&timer_list_lock);
    list_add_tail(&tsk->timewait.list, &timer_list);
    pthread_mutex_unlock(&timer_list_lock);

    fprintf(stdout, "tcp_set_timewait_timer: set TIME_WAIT timer for socket %p, timeout=%d (now=%llu)\n",
            tsk, tsk->timewait.timeout, now);
}

/*
 * 函数: tcp_timer_thread
 * ------------------------
 * 定时器线程，周期性扫描 timer_list 链表，调用 tcp_scan_timer_list() 处理超时定时器。
 * 线程启动时先初始化 timer_list，并记录当前基准时间 base_time。
 */
void *tcp_timer_thread(void *arg)
{
    // 初始化 timer_list 链表头
    init_list_head(&timer_list);
    // 记录程序启动时的基准时间（单位：微秒）
    base_time = current_time_us();
    while (1)
    {
        // 每隔 TCP_TIMER_SCAN_INTERVAL 微秒扫描一次
        usleep(TCP_TIMER_SCAN_INTERVAL);
        tcp_scan_timer_list();
    }

    return NULL;
}
