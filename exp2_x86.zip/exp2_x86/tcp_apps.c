#include "tcp_sock.h"
#include "log.h"
#include <unistd.h>
#include <string.h>

// 预定义数据字符串（数字+小写字母+大写字母）
static const char *DATA = "0123456789"
                          "abcdefghijklmnopqrstuvwxyz"
                          "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
#define DATA_LEN 62  // 10+26+26=62

// TCP服务器应用，实现echo功能并添加前缀
void *tcp_server(void *arg) {
    u16 port = *(u16 *)arg;
    struct tcp_sock *tsk = alloc_tcp_sock();

    struct sock_addr addr = {
        .ip = htonl(0),
        .port = port
    };

    if (tcp_sock_bind(tsk, &addr) < 0) {
        log(ERROR, "Bind port %hu failed", ntohs(port));
        exit(1);
    }

    if (tcp_sock_listen(tsk, 3) < 0) {
        log(ERROR, "Listen failed");
        exit(1);
    }

    log(DEBUG, "Listening on port %hu", ntohs(port));

    struct tcp_sock *csk = tcp_sock_accept(tsk);
    log(DEBUG, "Accepted connection");

    char buf[1024];
    char reply[1024 + 20];  // 预留前缀空间
    int recv_len;

    while (1) {
        recv_len = tcp_sock_read(csk, buf, sizeof(buf)-1);
        if (recv_len < 0) {
            log(ERROR, "Read error");
            break;
        } else if (recv_len == 0) {
            log(DEBUG, "Connection closed by client");
            break;
        }

        // 构造echo响应
        buf[recv_len] = '\0';
        snprintf(reply, sizeof(reply), "server echoes: %s", buf);
        tcp_sock_write(csk, reply, strlen(reply));
    }

    tcp_sock_close(csk);
    return NULL;
}

// TCP客户端应用，发送10次不同数据并接收响应
void *tcp_client(void *arg) {
    struct sock_addr *skaddr = arg;
    struct tcp_sock *tsk = alloc_tcp_sock();

    if (tcp_sock_connect(tsk, skaddr) < 0) {
        log(ERROR, "Connect to "IP_FMT":%hu failed", 
            NET_IP_FMT_STR(skaddr->ip), ntohs(skaddr->port));
        exit(1);
    }

    char send_buf[1024];
    char recv_buf[1024];

    for (int i = 0; i < 10; i++) {
        // 构造循环位移数据
        int offset = i % DATA_LEN;
        int tail_len = i  % DATA_LEN;
        
        // 第一部分：从offset到结尾
        int part1_len = DATA_LEN - offset;
        memcpy(send_buf, DATA + offset, part1_len);
        
        // 第二部分：从开头到tail_len
        if (tail_len > 0) {
            memcpy(send_buf + part1_len, DATA, tail_len);
        }
        
        // 发送组合数据
        int total_len = part1_len + tail_len;
        tcp_sock_write(tsk, send_buf, total_len);
        log(DEBUG, "Sent %d bytes (loop %d)", total_len, i+1);



        // 接收响应
        int recv_len = tcp_sock_read(tsk, recv_buf, sizeof(recv_buf)-1);
        if (recv_len > 0) {
            recv_buf[recv_len] = '\0';
            printf("%s\n", recv_buf);
        }

        sleep(1);
    }



    log(DEBUG, "循环发送数据结束"); 
    char* packet;
    int len =ETHER_HDR_SIZE + 
    IP_BASE_HDR_SIZE + 
    TCP_BASE_HDR_SIZE;
    packet=malloc(len);
    tcp_send_packet(tsk, packet, len);
    tcp_sock_close(tsk);
    return NULL;
}
