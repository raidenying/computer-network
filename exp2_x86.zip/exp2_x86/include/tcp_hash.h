#ifndef __TCP_HASH_H__
#define __TCP_HASH_H__

#include "hash.h"
#include "list.h"
#include "tcp_sock.h"

#define TCP_HASH_SIZE HASH_8BITS//定义哈希表大小
#define TCP_HASH_MASK (TCP_HASH_SIZE - 1)//计算哈希索引的掩码

//包含三个哈希表，分别用于存储已建立的连接（established_table）、监听的连接（listen_table）和绑定的连接（bind_table）。
struct tcp_hash_table {
	struct list_head established_table[TCP_HASH_SIZE];
	struct list_head listen_table[TCP_HASH_SIZE];
	struct list_head bind_table[TCP_HASH_SIZE];
};

//TCP哈希函数，根据源IP、目的IP、源端口和目的端口计算哈希值。如果哈希到bind_table或listen_table，仅使用源端口；否则使用所有四个参数。哈希结果与TCP_HASH_MASK进行按位与操作，得到哈希表的索引。
static inline int tcp_hash_function(u32 saddr, u32 daddr, u16 sport, u16 dport)
{
	int result = hash8((char *)&saddr, 4) ^ hash8((char *)&daddr, 4) ^ \
				 hash8((char *)&sport, 2) ^ hash8((char *)&dport, 2);

	return result & TCP_HASH_MASK;
}

#endif
