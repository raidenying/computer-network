#include "tcp.h"
#include "tcp_sock.h"
#include "tcp_timer.h"

#include "log.h"
#include "ring_buffer.h"

#include <stdlib.h>
// update the snd_wnd of tcp_sock
//
// if the snd_wnd before updating is zero, notify tcp_sock_send (wait_send)
static inline void tcp_update_window(struct tcp_sock *tsk, struct tcp_cb *cb)
{
    u16 old_snd_wnd = tsk->snd_wnd;
    tsk->snd_wnd = cb->rwnd;
    if (old_snd_wnd == 0)
        wake_up(tsk->wait_send);
}

// update the snd_wnd safely: cb->ack should be between snd_una and snd_nxt
static inline void tcp_update_window_safe(struct tcp_sock *tsk, struct tcp_cb *cb)
{
    if (less_or_equal_32b(tsk->snd_una, cb->ack) && less_or_equal_32b(cb->ack, tsk->snd_nxt))
        tcp_update_window(tsk, cb);
}

#ifndef max
#define max(x, y) ((x) > (y) ? (x) : (y))
#endif

// check whether the sequence number of the incoming packet is in the receiving
// window
static inline int is_tcp_seq_valid(struct tcp_sock *tsk, struct tcp_cb *cb)
{
    u32 rcv_end = tsk->rcv_nxt + max(tsk->rcv_wnd, 1);
    if (less_than_32b(cb->seq, rcv_end) && less_or_equal_32b(tsk->rcv_nxt, cb->seq_end))
    {
        return 1;
    }
    else
    {
        log(ERROR, "received packet with invalid seq, drop it.");
        return 0;
    }
}

// Process the incoming packet according to TCP state machine.
void tcp_process(struct tcp_sock *tsk, struct tcp_cb *cb, char *packet)
{
    switch (tsk->state)
    {

    case TCP_LISTEN:
        if (cb->flags & TCP_SYN)
        {
            struct tcp_sock *child = alloc_tcp_sock();
            if (!child)
            {
                fprintf(stderr, "tcp_process: alloc_tcp_sock failed\n");
                return;
            }
            child->parent = tsk;
            // ====== 修复点1：初始化四元组 ======
            // 设置子套接字的本地地址（必须明确指定为服务器实际IP，不能为0.0.0.0）
            child->sk_sip = cb->daddr;       // SYN包中的目标IP（即服务器IP：10.0.0.1）
            child->sk_sport = tsk->sk_sport; // 服务器端口（10001）

            // 设置子套接字的对端地址（客户端地址）
            child->sk_dip = cb->saddr;   // SYN包的源IP（客户端IP：10.0.0.2）
            child->sk_dport = cb->sport; // SYN包的源端口（客户端端口：12345）

            child->rcv_wnd = TCP_DEFAULT_WINDOW;
            child->snd_wnd = TCP_DEFAULT_WINDOW;

            // ====== 修复点2：初始化序列号 ======
            child->iss = tcp_new_iss();
            child->snd_nxt = child->iss; // 生成初始序列号

            child->rcv_nxt = cb->seq_end; // 期待客户端的ACK确认号为 seq+1
            child->snd_una = 0;
            // child->snd_una =cb->ack
            // child->adv_wnd = cb->rwnd;
            //  ====== 修复点3：状态转移 ======

            tcp_set_state(child, TCP_SYN_RECV);

            // ====== 发送SYN-ACK包 ======

            tcp_send_control_packet(child, TCP_SYN | TCP_ACK);
            tcp_hash(child); // 将子套接字加入listen_table（确保能收到后续ACK）
        }
        break;
    case TCP_SYN_SENT:
        // 客户端：在 SYN_SENT 状态下，等待接收 SYN+ACK 报文
        if ((cb->flags & (TCP_SYN | TCP_ACK)) == (TCP_SYN | TCP_ACK))
        {
            if (tsk->snd_nxt == cb->ack)
            {
                tsk->rcv_nxt = cb->seq_end;
                tsk->adv_wnd = cb->rwnd;
                tsk->snd_una = cb->ack;
                tcp_set_state(tsk, TCP_ESTABLISHED);
                tcp_send_control_packet(tsk, TCP_ACK);
                wake_up(tsk->wait_connect);
            }
        }
        // if(cb->flags&TCP_RST)
        // {
        //     tcp_set_state(tsk,TCP_CLOSED);
        //     free_tcp_sock(tsk);
        // }
        break;

    case TCP_SYN_RECV:
        // 服务器端子 socket：等待客户端的 ACK 确认
        if (cb->flags & TCP_ACK)
        {
            //确保序列号正确
            if (cb->ack == tsk->snd_nxt)
            {
                tsk->adv_wnd = cb->rwnd;
                tsk->rcv_nxt = cb->seq_end;
                tsk->snd_una = cb->ack;
                tcp_set_state(tsk, TCP_ESTABLISHED);

                // 将子套接字加入accept队列
                tcp_sock_accept_enqueue(tsk);
                wake_up(tsk->parent->wait_accept); // 唤醒accept阻塞
            }
        }
        break;

    case TCP_ESTABLISHED:
        // 已建立连接状态下：处理数据、ACK 以及 FIN 报文
        if (cb->pl_len > 0)
        {
            size_t free_space = ring_buffer_free(tsk->rcv_buf);
            if (free_space < cb->pl_len) {
                // 当接收缓冲区剩余空间不足时，设置接收窗口大小为0，并发送ACK包
                tsk->rcv_wnd = 0;
                tcp_send_control_packet(tsk, TCP_ACK);
                break;
            }
        
            // 更新发送方的下一个预期序列号和接收窗口大小
            tsk->snd_una = cb->ack;
            tsk->adv_wnd = cb->rwnd;
        
            //log(DEBUG,"%s", tsk->rcv_buf);
            // 更新接收方的下一个预期序列号，并将数据写入缓冲区
            tsk->rcv_nxt = cb->seq_end;
            write_ring_buffer(tsk->rcv_buf, cb->payload, cb->pl_len);
        
            // 重新计算接收窗口大小，并唤醒等待接收数据的线程
            tsk->rcv_wnd = ring_buffer_free(tsk->rcv_buf);
            wake_up(tsk->wait_recv);
        }
        if (cb->flags & TCP_ACK)
        {
            tsk->adv_wnd = cb->rwnd;
            tsk->snd_una = cb->ack;
            if (tsk->snd_nxt > tsk->snd_una)
                wake_up(tsk->wait_send);
        }
        if (cb->flags & TCP_FIN)
        {
            tsk->rcv_nxt = cb->seq_end;
            // 对端发起关闭：先回复 ACK，然后进入 CLOSE_WAIT 状态
            tcp_send_control_packet(tsk, TCP_ACK);
            tcp_set_state(tsk, TCP_CLOSE_WAIT);
            wake_up(tsk->wait_recv);
        }
        break;

    case TCP_FIN_WAIT_1:
        // 在主动关闭的一方，当自己发送 FIN 后进入 FIN_WAIT_1 状态
        if (cb->flags & TCP_ACK)
        {
            // 仅收到 ACK：对方确认了自己的 FIN，但未发送 FIN
            // 则进入 FIN_WAIT_2 状态，等待对方发 FIN
            tcp_set_state(tsk, TCP_FIN_WAIT_2);
        }
        break;

    case TCP_FIN_WAIT_2:
        // 在 FIN_WAIT_2 状态，等待对方发送 FIN
        if (cb->flags & TCP_FIN)
        {
            tsk->rcv_nxt = cb->seq + 1;
            // 收到 FIN 后，回复 ACK，表示确认对方的关闭请求
            tcp_send_control_packet(tsk, TCP_ACK);
            // 然后进入 TIME_WAIT 状态，并启动定时器
            tcp_set_state(tsk, TCP_TIME_WAIT);
            tcp_set_timewait_timer(tsk);
        }
        if (cb->pl_len > 0) {
            // 更新发送方已确认的最大序列号
            tsk->snd_una = cb->ack;
            
            // 更新接收方的接收窗口大小
            tsk->adv_wnd = cb->rwnd;
            
            // 更新接收方期望接收的下一个序列号
            tsk->rcv_nxt = cb->seq_end;
            
            // 将接收到的数据写入接收缓冲区
            write_ring_buffer(tsk->rcv_buf, cb->payload, cb->pl_len);
            
            // 唤醒等待接收数据的线程
            wake_up(tsk->wait_recv);
        }
        break;

        // case TCP_CLOSING:
        //     // CLOSING 状态：双方几乎同时关闭连接，本端已发送 FIN，但还未收到对方 ACK
        //     if (cb->flags & TCP_ACK)
        //     {
        //         // 收到对方的 ACK 后，进入 TIME_WAIT 状态，等待足够时间后彻底关闭
        //         tcp_set_state(tsk,TCP_TIME_WAIT);
        //         tcp_set_timewait_timer(tsk);
        //     }
        //     break;
        // 服务端收到fin后只发送了ack，还未发送fin

    case TCP_CLOSE_WAIT:
        if (cb->flags & TCP_ACK)
        {
            tsk->rcv_nxt = cb->seq_end;
            tsk->snd_una = cb->ack;
            tsk->adv_wnd = cb->rwnd;
        }
        if (cb->flags & TCP_RST)
        {
            tcp_set_state(tsk, TCP_CLOSED);
            free_tcp_sock(tsk);
        }

        break;

    case TCP_LAST_ACK:
        if (cb->flags & TCP_ACK)
        {
            tcp_set_state(tsk, TCP_CLOSED);
            tcp_unhash(tsk);
            tcp_bind_unhash(tsk);
            // free_tcp_sock(tsk);
        }
        break;

    default:
        fprintf(stdout, "tcp_process: Unknown TCP state %d.\n", tsk->state);
        break;
    }
}
